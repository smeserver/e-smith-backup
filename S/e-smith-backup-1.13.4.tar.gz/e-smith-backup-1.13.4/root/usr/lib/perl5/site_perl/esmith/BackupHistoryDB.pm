#----------------------------------------------------------------------
# Copyright 1999-2003 Mitel Networks Corporation
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
#----------------------------------------------------------------------

package esmith::BackupHistoryDB;

use strict;
use warnings;

use esmith::DB::db;
our @ISA = qw( esmith::DB::db );

=head1 NAME

esmith::BackupHistoryDB - interface to esmith backup history database

=head1 SYNOPSIS

    use esmith::BackupHistoryDB;
    my $c = esmith::BackupHistoryDB->open;

    # everything else works just like esmith::DB::db

=head1 DESCRIPTION

This module provides an abstracted interface to the esmith master
configuration database.

Unless otherwise noted, esmith::BackupHistoryDB acts like esmith::DB::db.

=cut

=head2 open()

Like esmith::DB->open, but if given no $file it will try to open the
file in the ESMITH_BACKUPHISTORY_DB environment variable or "backups" in
the default database directory.

=begin testing

use_ok("esmith::BackupHistoryDB");

$C = esmith::BackupHistoryDB->open('10e-smith-backup/backuphistory.conf');
isa_ok($C, 'esmith::BackupHistoryDB');

my $rec = $C->get('1053551285');
isa_ok($rec, 'esmith::DB::Record');

is( $rec->prop('EndEpochTime'), 1053551299,
                                    "We can get stuff from the db");

=end testing

=cut

sub open {
    my($class, $file) = @_;
    $file = $file || $ENV{ESMITH_BACKUPHISTORY_DB} || "backups";
    return $class->SUPER::open($file) || $class->SUPER::create($file);
}

=head2 open_ro()

Like esmith::DB->open_ro, but if given no $file it will try to open the
file in the ESMITH_BACKUPHISTORY_DB environment variable or "backups" in
the default database directory.

=begin testing

=end testing

=cut

sub open_ro {
    my($class, $file) = @_;
    $file = $file || $ENV{ESMITH_BACKUPHISTORY_DB} || "backups";
    return $class->SUPER::open_ro($file);
}

=head1 AUTHOR

SME Server Developers <bugs@e-smith.com>

=head1 SEE ALSO

L<esmith::DB::db>

L<esmith::DB::Record>

=cut

1;
